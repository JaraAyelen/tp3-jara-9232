#!/bin/bash

# Validación del argumento (Nombre Completo)
if [ "$#" -ne 1 ]; then
    echo "Error: Debe ingresar su Nombre Completo como argumento (entre comillas)." >&2
    exit 1
fi

# Asignación del primer parámetro posicional (Nombre Completo) a la variable local
NOMBRE="$1"

# Preparación del directorio y archivo log
mkdir -p logs
ARCHIVO_LOG="logs/diagnostico_9232.log"

# Recopilación de datos
{
	echo "---------------------------------------------------------------------"
	echo "Iniciando diagnóstico para el administrador: $NOMBRE"
	echo
	echo "Fecha y hora actual: $(date +'%Y-%m-%d %H:%M:%S')"
	echo
	echo "Tiempo de actividad del sistema: $(uptime -p)"
	echo
	echo "Porcentaje de uso del disco en la partición raíz (/):"
	df -h /
	echo
	echo "Espacio disponible en el directorio /home:"
	df -h /home
	echo
	echo "Usuarios conectados en este momento:"
	who
	echo
	echo "Dirección IP local:"
	hostname -I
	echo "---------------------------------------------------------------------"
} | tee -a "$ARCHIVO_LOG"

# Mensaje de confirmación final
echo "Esta información se guardó correctamente en $ARCHIVO_LOG"
