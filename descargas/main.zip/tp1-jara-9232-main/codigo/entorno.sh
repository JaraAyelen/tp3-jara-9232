#!/bin/bash

# Asignación de variables
LEGAJO="9232"
DNI="2079"

# Preparación del archivo
mkdir -p logs
ARCHIVO_LOG="logs/entorno_${LEGAJO}.txt"

# Imprimir la versión actual de Bash
echo "Versión de Bash actual: $BASH_VERSION" > "$ARCHIVO_LOG"

# Mostrar el contenido de la variable PATH
echo "Contenido de la variable PATH: $PATH" >> "$ARCHIVO_LOG"

# Generar el Token de Autenticidad
TOKEN="${LEGAJO}${DNI}"

#  Imprimir el Token generado
echo "Token de Autenticidad: $TOKEN" >> "$ARCHIVO_LOG"

echo "La información se guardó correctamente en $ARCHIVO_LOG"
