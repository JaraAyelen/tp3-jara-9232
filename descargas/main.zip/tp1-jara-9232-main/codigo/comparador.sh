#!/bin/bash

# Validación de la cantidad de argumentos (dos)
if [ "$#" -ne 2 ]; then
    echo "Error: Debe ingresar dos argumentos numéricos." >&2
    exit 2
fi

# Validación del tipo de dato (números enteros)
if ! [[ $1 =~ ^-?[0-9]+$ ]] || ! [[ $2 =~ ^-?[0-9]+$ ]]; then
    echo "Error: Ambos argumentos deben ser números enteros." >&2
    exit 3
fi

# Asignación de los parámetros posicionales a variables locales
A=$1
B=$2

# Operaciones básicas
SUMA=$((A + B))
RESTA=$((A - B))
MULT=$((A * B))

# División entera y módulo (validando que B no sea 0)
if [ "$B" -eq 0 ]; then
    echo "Atención: No se puede dividir por cero (N/A=No Aplica)." >&2
    DIV="N/A"
    MOD="N/A"
else
    DIV=$((A / B))
    MOD=$((A % B))
fi

# Comparaciones
if [ "$A" -eq "$B" ]; then
    COMPARACION="Ambos números son iguales"
elif [ "$A" -gt "$B" ]; then
    COMPARACION="$A es mayor que $B"
else
    COMPARACION="$B es mayor que $A"
fi

# Salida en formato de tabla Markdown
echo ""
echo "| Operación | Expresión | Resultado |"
echo "| :--- | :--- | :--- |"
echo "| Suma | $A + $B | $SUMA |"
echo "| Resta | $A - $B | $RESTA |"
echo "| Multiplicación | $A * $B | $MULT |"
echo "| División | $A / $B | $DIV |"
echo "| Resto (módulo) | $A % $B | $MOD |"
echo "| Comparación | N/A | $COMPARACION |"
echo ""
