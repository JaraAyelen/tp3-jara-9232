# Trabajo Práctico N° 1 - Revisión de conceptos y scripts básicos

**Carrera:** Tecnicatura Universitaria en Administración de Sistemas y Software Libre 

**Asignatura:** Automatización y Scripting

**Alumna:** Jara Ayelen 

**Legajo N°:** 9232

## Descripción
El presente repositorio contiene la resolución del Trabajo Práctico N° 1 de la asignatura Automatización y Scripting. El mismo consiste en la creación de scripts básicos de Bash para automatizar la recopilación de datos y operaciones aritméticas simples, empleando parámetros y buenas prácticas de depuración.

## Estructura del Proyecto
* `codigo/`: Contiene los scripts desarrollados.
* `logs/`: Guarda los archivos que se generan al ejecutar y probar el código.
* `capturas/`: Capturas de pantalla de la terminal mostrando la ejecución exitosa de los scripts.

## Scripts Desarrollados
1. **entorno.sh**: Genera un archivo donde guarda la versión del intérprete, el contenido de la variable $PATH y un token de autenticidad.

![Ejecución de entorno.sh](capturas/1.captura_entorno.png)

2. **diagnostico.sh**: Recopila información del estado del sistema operativo (fecha y hora actual, tiempo de actividad, uso de disco, usuarios conectados, IP) y la guarda en un archivo de log.

![Ejecución de diagnostico.sh](capturas/2.captura_diagnostico.png)

3. **comparador.sh**: Realiza operaciones aritméticas y comparaciones entre dos números enteros que se ingresan como parámetros, y la salida se presenta en formato de tabla Markdown.

![Ejecución de comparador.sh](capturas/3.captura_comparador.png)
